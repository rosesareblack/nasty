export const Colors = {
  // Dark theme colors
  background: '#0a0a0a',
  surface: '#1a1a1a',
  surfaceLight: '#2a2a2a',
  border: '#333333',
  borderLight: '#404040',
  
  // Text colors
  text: '#ffffff',
  textSecondary: '#a0a0a0',
  textMuted: '#666666',
  
  // Brand colors
  primary: '#3b82f6',
  primaryDark: '#2563eb',
  accent: '#8b5cf6',
  success: '#22c55e',
  warning: '#f59e0b',
  error: '#ef4444',
  
  // AI specific
  aiGradient: ['#3b82f6', '#8b5cf6'],
  userMessage: '#2563eb',
  aiMessage: '#1a1a1a',
};

export const Spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
};

export const BorderRadius = {
  sm: 4,
  md: 8,
  lg: 12,
  xl: 16,
};

import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  StyleSheet,
  KeyboardAvoidingView,
  Keyboard,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';

// Static types - no runtime type checking overhead
interface Message {
  id: string;
  content: string;
  sender: 'user' | 'ai';
  timestamp: number;
  code?: string;
}

// Pre-computed constants - deterministic values
const COLORS = {
  bg: '#0a0a0a',
  surface: '#1a1a1a',
  border: '#333333',
  text: '#ffffff',
  textSub: '#666666',
  accent: '#3b82f6',
} as const;

const SIZES = {
  input: 48,
  button: 40,
  radius: 12,
  spacing: 16,
} as const;

// Deterministic AI service - single execution path
class FastAI {
  private static cache = new Map<string, { content: string; code?: string }>();
  
  static async generate(input: string, signal: AbortSignal): Promise<{ content: string; code?: string }> {
    // Cache hit - zero latency path
    const cached = this.cache.get(input);
    if (cached) return cached;

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer rofOt1XLZwuCaYZ24hUuNRnGpNCBkUEa',
      },
      body: JSON.stringify({
        model: 'gpt-3.5-turbo',
        messages: [
          {
            role: 'system',
            content: 'You are OnSpace AI. Provide concise React Native code solutions. Always include working code examples.'
          },
          { role: 'user', content: input }
        ],
        max_tokens: 1500,
        temperature: 0.1, // Deterministic outputs
        stream: false,
      }),
      signal,
    });

    if (!response.ok) throw new Error(`API Error: ${response.status}`);
    
    const data = await response.json();
    const content = data.choices[0]?.message?.content || '';
    
    // Parse code blocks deterministically
    const codeMatch = content.match(/```(?:typescript|javascript|tsx|jsx)?\n?([\s\S]*?)```/);
    const result = {
      content: content.replace(/```[\s\S]*?```/g, '').trim(),
      code: codeMatch?.[1]?.trim(),
    };

    // Cache for zero-latency future hits
    this.cache.set(input, result);
    return result;
  }
}

// Pre-computed styles - no runtime StyleSheet.create overhead
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.bg },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: SIZES.spacing,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
  },
  logo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  logoIcon: {
    width: 32,
    height: 32,
    backgroundColor: COLORS.surface,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  title: {
    fontSize: 18,
    fontWeight: '600',
    color: COLORS.text,
  },
  chat: { flex: 1 },
  messagesList: {
    paddingHorizontal: SIZES.spacing,
    paddingVertical: SIZES.spacing,
  },
  message: { marginBottom: 20 },
  messageHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  avatar: {
    width: 24,
    height: 24,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 8,
  },
  avatarUser: { backgroundColor: COLORS.text },
  avatarAI: { backgroundColor: COLORS.surface },
  sender: {
    fontSize: 14,
    fontWeight: '600',
    color: COLORS.text,
    marginRight: 8,
  },
  messageText: {
    fontSize: 16,
    lineHeight: 22,
    color: COLORS.text,
    maxWidth: '90%',
  },
  codeBlock: {
    backgroundColor: COLORS.surface,
    borderRadius: 8,
    padding: 12,
    marginTop: 8,
    maxWidth: '90%',
  },
  codeHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  codeHeaderText: {
    fontSize: 12,
    color: COLORS.textSub,
    marginLeft: 6,
  },
  codeText: {
    fontSize: 14,
    fontFamily: 'monospace',
    color: COLORS.text,
    lineHeight: 18,
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 32,
  },
  emptyIcon: {
    width: 80,
    height: 80,
    backgroundColor: COLORS.surface,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 24,
  },
  emptyTitle: {
    fontSize: 24,
    fontWeight: '600',
    color: COLORS.text,
    marginBottom: 8,
    textAlign: 'center',
  },
  emptySubtitle: {
    fontSize: 16,
    color: COLORS.textSub,
    textAlign: 'center',
    lineHeight: 22,
  },
  inputContainer: {
    paddingHorizontal: SIZES.spacing,
    paddingVertical: SIZES.spacing,
    borderTopWidth: 1,
    borderTopColor: COLORS.border,
  },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    backgroundColor: COLORS.surface,
    borderRadius: SIZES.radius * 1.5,
    paddingLeft: SIZES.spacing,
    paddingRight: 4,
    paddingVertical: 4,
    minHeight: SIZES.input,
  },
  input: {
    flex: 1,
    fontSize: 16,
    color: COLORS.text,
    paddingVertical: 12,
    paddingRight: 12,
    maxHeight: 120,
  },
  sendButton: {
    width: SIZES.button,
    height: SIZES.button,
    borderRadius: SIZES.button / 2,
    backgroundColor: COLORS.text,
    alignItems: 'center',
    justifyContent: 'center',
  },
  sendButtonDisabled: {
    backgroundColor: COLORS.border,
  },
});

export default function OnSpaceAI() {
  // Minimal state - single source of truth
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  
  // Refs for deterministic behavior
  const flatListRef = useRef<FlatList>(null);
  const abortControllerRef = useRef<AbortController | null>(null);

  // Deterministic message renderer - pre-memoized
  const renderMessage = useCallback(({ item }: { item: Message }) => (
    <View style={styles.message}>
      <View style={styles.messageHeader}>
        <View style={[styles.avatar, item.sender === 'user' ? styles.avatarUser : styles.avatarAI]}>
          <MaterialIcons 
            name={item.sender === 'user' ? 'person' : 'auto-awesome'} 
            size={16} 
            color={item.sender === 'user' ? COLORS.bg : COLORS.text} 
          />
        </View>
        <Text style={styles.sender}>
          {item.sender === 'user' ? 'You' : 'OnSpace AI'}
        </Text>
      </View>
      
      {item.content ? (
        <Text style={styles.messageText} selectable>
          {item.content}
        </Text>
      ) : null}
      
      {item.code ? (
        <View style={styles.codeBlock}>
          <View style={styles.codeHeader}>
            <MaterialIcons name="code" size={14} color={COLORS.textSub} />
            <Text style={styles.codeHeaderText}>Generated Code</Text>
          </View>
          <Text style={styles.codeText} selectable>
            {item.code}
          </Text>
        </View>
      ) : null}
    </View>
  ), []);

  // Fast scroll to bottom - single operation
  const scrollToBottom = useCallback(() => {
    requestAnimationFrame(() => {
      flatListRef.current?.scrollToEnd({ animated: true });
    });
  }, []);

  // Deterministic send function - single execution path
  const sendMessage = useCallback(async () => {
    if (!input.trim() || loading) return;

    const userMessage: Message = {
      id: `${Date.now()}`,
      content: input.trim(),
      sender: 'user',
      timestamp: Date.now(),
    };

    // Cancel any pending request
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }

    // Update state in single batch
    const messageText = input.trim();
    setInput('');
    setMessages(prev => [...prev, userMessage]);
    setLoading(true);

    // Create abort controller for cancellation
    abortControllerRef.current = new AbortController();

    try {
      // AI generation with deterministic timeout
      const result = await FastAI.generate(messageText, abortControllerRef.current.signal);
      
      const aiMessage: Message = {
        id: `${Date.now()}_ai`,
        content: result.content,
        code: result.code,
        sender: 'ai',
        timestamp: Date.now(),
      };

      setMessages(prev => [...prev, aiMessage]);
      scrollToBottom();
    } catch (error: any) {
      if (error.name !== 'AbortError') {
        const errorMessage: Message = {
          id: `${Date.now()}_error`,
          content: 'Sorry, I encountered an error. Please try again.',
          sender: 'ai',
          timestamp: Date.now(),
        };
        setMessages(prev => [...prev, errorMessage]);
      }
    } finally {
      setLoading(false);
      abortControllerRef.current = null;
    }
  }, [input, loading, scrollToBottom]);

  // Auto-scroll on new messages
  useEffect(() => {
    if (messages.length > 0) {
      scrollToBottom();
    }
  }, [messages.length, scrollToBottom]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }
    };
  }, []);

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <KeyboardAvoidingView 
        style={styles.container}
        behavior="padding"
      >
        {/* Static header - no re-renders */}
        <View style={styles.header}>
          <View style={styles.logo}>
            <View style={styles.logoIcon}>
              <MaterialIcons name="auto-awesome" size={20} color={COLORS.text} />
            </View>
            <Text style={styles.title}>OnSpace AI</Text>
          </View>
        </View>

        {/* Chat area */}
        <View style={styles.chat}>
          {messages.length === 0 ? (
            <View style={styles.emptyState}>
              <View style={styles.emptyIcon}>
                <MaterialIcons name="code" size={48} color={COLORS.textSub} />
              </View>
              <Text style={styles.emptyTitle}>Start Building with AI</Text>
              <Text style={styles.emptySubtitle}>
                Describe what you want to build and I will generate the code
              </Text>
            </View>
          ) : (
            <FlatList
              ref={flatListRef}
              data={messages}
              renderItem={renderMessage}
              keyExtractor={item => item.id}
              contentContainerStyle={styles.messagesList}
              showsVerticalScrollIndicator={false}
              removeClippedSubviews={true}
              maxToRenderPerBatch={10}
              windowSize={10}
            />
          )}
        </View>

        {/* Input - optimized for speed */}
        <View style={styles.inputContainer}>
          <View style={styles.inputWrapper}>
            <TextInput
              style={styles.input}
              value={input}
              onChangeText={setInput}
              placeholder="Describe what you want to build..."
              placeholderTextColor={COLORS.textSub}
              multiline
              maxLength={2000}
              editable={!loading}
              onSubmitEditing={sendMessage}
              returnKeyType="send"
            />
            <TouchableOpacity
              style={[
                styles.sendButton,
                (!input.trim() || loading) && styles.sendButtonDisabled
              ]}
              onPress={sendMessage}
              disabled={!input.trim() || loading}
            >
              {loading ? (
                <ActivityIndicator size={20} color={COLORS.bg} />
              ) : (
                <MaterialIcons 
                  name="send" 
                  size={20} 
                  color={COLORS.bg} 
                />
              )}
            </TouchableOpacity>
          </View>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}
